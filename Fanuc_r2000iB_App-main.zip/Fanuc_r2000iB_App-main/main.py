# kivy enviroment
import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider

from kivy.properties import ObjectProperty, StringProperty

# um den client aufzubauen
from opcua import Client
from opcua import ua

from time import sleep

class WindowManager(ScreenManager):
    """
    Managet alle Windows --> Kivy file // im pythonskript vernachlässigbar

    """

    pass


class HomeScreen(Screen):
    """
    einfacher Homescreen --> keine Funktionen nur umschaltungen
    -> Design im Kivy file

    """
    pass


class RemoteScreen(Screen, FloatLayout):
    """
    In dem Bildschirm wird der Roboter mit Slidern ferngesteuert
    -> Design im Kivy file

    """


    #gloable Bool-Variable --> False==keineConnection; True==connection
    #default wert Fals--> keine connection
    opcua_connect = False

    #globale Objekte für verschiedene Label
    connect_label = None
    disconnect_label = None
    connect_fail_label = None
    try_connect_label = None

    #für den Aufbau des Clients...
    url = "opc.tcp://192.168.0.4:4840"
    client = Client("opc.tcp://192.168.0.4:4840")

    j1Value = StringProperty("JOINT 1: ")
    j2Value = StringProperty("JOINT 2: ")
    j3Value = StringProperty("JOINT 3: ")
    j4Value = StringProperty("JOINT 4: ")
    j5Value = StringProperty("JOINT 5: ")
    j6Value = StringProperty("JOINT 6: ")


    def opcua_controll(self):
        if not self.opcua_connect:

            # wenn der Button 'opcua connection' betätigt wurde und vorher keine Verbindung bestand wird eine hergestellt
            self.try_connect_label = Label(text="try connecting...", size_hint=(0.7, 0.05),
                                           pos_hint={"x": 0.15, "y": 0.825}, color=(0, 1, 0, 1))
            self.add_widget(self.try_connect_label)


            try:

                # falls vorher das disconnect Label geprintet wurde, wird es entfernt...
                if self.disconnect_label is not None:
                    self.remove_widget(self.disconnect_label)

                #falls vorher der connect fail Label geprintet wurde, wird es entfernt...
                if self.connect_fail_label is not None:
                    self.remove_widget(self.connect_fail_label)

                print("try connecting...")

                self.client.connect()
                self.opcua_connect = True

                print("connect sucesfully!")
                # Label zur Bestätigung das die connection erfolgreich war.

                if self.try_connect_label is not None:
                    self.remove_widget(self.try_connect_label)


                self.connect_label = Label(text="OPC-UA erfolgreich connected...", size_hint=(0.7, 0.05),
                                           pos_hint={"x": 0.15, "y": 0.825}, color=(0, 1, 0, 1))
                self.add_widget(self.connect_label)


            except:
                #bei fehlgeschlagener Connection -->

                if self.try_connect_label is not None:
                    self.remove_widget(self.try_connect_label)

                print("connection fehlgeschlagen")
                self.connect_fail_label = Label(text="OPC-UA CONNECTION FEHLGESCHLAGEN...", size_hint=(0.7, 0.05),
                                           pos_hint={"x": 0.15, "y": 0.825}, color=(1, 0, 0, 1))
                self.add_widget(self.connect_fail_label)



        elif self.opcua_connect:
            # wird auf dem connection Button gedrückt während der Client aufgebaut ist wird disconnected
            print("disconnecting opcua...")
            self.client.disconnect()
            self.opcua_connect = False
            print("opcua disconnected")

            # gibt es einen connection label wird dieser entfernt
            if self.connect_label is not None:
                self.remove_widget(self.connect_label)

            # Label für das erfolgreiche disconnecten wird geprintet
            self.disconnect_label = Label(text="OPC_UA erfolgreich disconnected...", size_hint=(0.7, 0.05),
                                          pos_hint={"x": 0.15, "y": 0.825}, color=(1, 0, 0, 1))
            self.add_widget(self.disconnect_label)


    def update_j1(self):
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte
        self.j1Value = "JOINT1 : {}".format(self.ids["joint1"].value)
        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint1"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j1"', value=value)

    def update_j2(self):
        self.j2Value = "JOINT2 : {}".format(self.ids["joint2"].value)
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte

        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint2"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j2"', value=value)

    def update_j3(self):
        self.j3Value = "JOINT3 : {}".format(self.ids["joint3"].value)
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte

        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint3"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j3"', value=value)

    def update_j4(self):
        self.j4Value = "JOINT4 : {}".format(self.ids["joint4"].value)
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte

        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint4"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j4"', value=value)

    def update_j5(self):
        self.j5Value = "JOINT5 : {}".format(self.ids["joint5"].value)
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte

        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint5"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j5"', value=value)

    def update_j6(self):
        self.j6Value = "JOINT6 : {}".format(self.ids["joint6"].value)
        #updatet bei jeder Berührung den Roboter anhant der Slider Werte

        if self.opcua_connect:
            #wenn eine OPC-UA Verbindung hergestellt ist...
            value = self.ids["joint6"].value
            self.setNodeValue(node_id='ns=3;s="r2000ib"."OutputJoint_real"."j6"', value=value)



    def setNodeValue(self, node_id, value):

        """
        mit der funktion kann man mithilfe der Slider den Roboter kontrollieren

        """

        #wird in den Update Funktionen genutzt, um ständig den Roboter der zu aktualisieren
        node = self.client.get_node(node_id)
        variant_type = node.get_data_type_as_variant_type()
        data_value = ua.DataValue(ua.Variant(value, variant_type))
        node.set_attribute(ua.AttributeIds.Value, data_value)



class FANUC_REMOTE(App):

    """
    Main Klasse --> Die Klasse erbt von kivy.app.App, somit enthält sie die funktion build
    die funktion wird mit der methode FANUC_REMOTE().run() auseführt; ist die funktion leer
    wird ein kivy file geöffnet mit dem selben Namen der Klasse

    """

    def build(self):
        """
        gibt nichts zurück, somit wird fanuc_remote.kv(name der App in lower() buchstaben!) aufgerufen

        """

        pass


if __name__ == '__main__':
    """
    in der Main methode wird das objekt instanziiert und die methode run aufgerufen
    -> damit startet die App

    """

    robot = FANUC_REMOTE()
    robot.run()
